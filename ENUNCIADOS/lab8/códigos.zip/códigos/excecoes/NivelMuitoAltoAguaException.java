package excecoes;

public class NivelMuitoAltoAguaException extends CafeteiraException{

    public NivelMuitoAltoAguaException (){
    
        super("Nível de água muito alto!");
    
    }

}
