package excecoes;

public class NivelMuitoBaixoLeiteException extends CafeteiraException{

    public NivelMuitoBaixoLeiteException (){
    
        super("Nível de leite muito baixo!");
    
    }

}
