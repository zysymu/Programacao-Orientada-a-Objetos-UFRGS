package excecoes;

public class NivelMuitoBaixoCafeException extends CafeteiraException{

    public NivelMuitoBaixoCafeException (){
    
        super("Nível de café muito baixo!");
        
    }

}
