package excecoes;

public class NivelMuitoAltoLeiteException extends CafeteiraException{

    public NivelMuitoAltoLeiteException (){
    
        super("Nível de leite muito alto!");
    
    }

}
