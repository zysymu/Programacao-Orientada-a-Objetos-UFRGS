package excecoes;

public class CafeteiraException extends Exception{

    public CafeteiraException (String mensagem){
    
        super(mensagem);
    
    }

}
