package excecoes;

public class NivelMuitoBaixoAguaException extends CafeteiraException{

    public NivelMuitoBaixoAguaException (){
    
        super("Nível de água muito baixo!");
    
    }

}
