package excecoes;

public class FaltaEstoqueException extends Exception{

    public FaltaEstoqueException (String mensagem){
    
        super(mensagem);
    
    }

}
