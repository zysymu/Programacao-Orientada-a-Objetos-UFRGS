package excecoes;

public class NivelMuitoAltoCafeException extends CafeteiraException{

    public NivelMuitoAltoCafeException (){
    
        super("Nível de café muito alto!");
    
    }

}
