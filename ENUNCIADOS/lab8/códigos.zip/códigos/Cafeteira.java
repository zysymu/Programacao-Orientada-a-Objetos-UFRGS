import excecoes.*;

public class Cafeteira{

    private double nivelCafe;
    private double nivelAgua;
    private double nivelLeite;
    
    public Cafeteira(){
        this.nivelCafe = 0; 
        this.nivelAgua = 0;
        this.nivelLeite = 0;
    }
    
    /* Anunciar e lançar exceções: NivelMuitoBaixoCafeException, NivelMuitoBaixoAguaException e NivelMuitoBaixoLeiteException! */
    public void pedir(String cafe){
        double quantCafe, quantAgua, quantLeite;
        if(cafe.equals("Latte")){
             quantCafe = 30;
             quantAgua = 40;
             quantLeite = 130;
        }
        else if(cafe.equals("Expresso")){
             quantCafe = 30;
             quantAgua = 70;
             quantLeite = 0;
        }
        else{
             quantCafe = 40;
             quantAgua = 160;
             quantLeite = 0;
        }
        this.nivelCafe -= quantCafe;
        this.nivelAgua -= quantAgua;
        this.nivelLeite -= quantLeite;        
    }
    
    /* Anunciar e lançar exceção NivelMuitoAltoCafeException! */
    public void completarNivelCafe(double quantidade){
        if(this.nivelCafe < 400) // Cabe 0,5 quilograma (Se o nível atual é menor que 400g, então adicionamos quantidade! Senão, considera-se quase cheio! )
           this.nivelCafe += quantidade;
    }

    /* Anunciar e lançar exceção NivelMuitoAltoAguaException! */
    public void completarNivelAgua(double quantidade){
        if(this.nivelAgua < 900) // Cabe 1 litro (Se o nível atual é menor que 900ml, então adicionamos quantidade! Senão, considera-se quase cheio! )
           this.nivelAgua += quantidade;
    }

    /* Anunciar e lançar exceção NivelMuitoAltoLeiteException! */
    public void completarNivelLeite(double quantidade){
        if(this.nivelLeite < 400) // Cabe 0,5 litro (Se o nível atual é menor que 400ml, então adicionamos quantidade! Senão, considera-se quase cheio! )
           this.nivelLeite += quantidade;
    }
    
    public String toString(){
        return "Café: " + this.nivelCafe + " | Água: " + this.nivelAgua + " | Leite: " + this.nivelLeite;
    }

}
